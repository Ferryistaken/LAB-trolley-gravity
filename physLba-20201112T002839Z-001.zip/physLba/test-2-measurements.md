## Second Test Measurements

1 book:
- 13.97 cm Height
2 books:
- 17.145 cm
3 books:
- 20.955 cm
4 books:
- 22.86 cm
5 books:
- 27.305 cm